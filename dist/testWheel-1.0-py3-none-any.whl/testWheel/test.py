from testWheel.__init__ import * 
def func_test(): 
    print("Successfully Imported test.py file") 
def print_name(name): 
    print(f'Hello {name}') 
def print_something():
    print("something")
def print_fangchen():
    print("I am Fang Chen")
def print_test_age(age): 
    print_age(age)
